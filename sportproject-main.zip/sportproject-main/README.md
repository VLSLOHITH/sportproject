<b>This is a project to manage the sports equipment of the campus and digitalize the process of maintaining records of equipment with information like roll number, date of issue, date of return, etc. 

This website has different views or functionalities based on the user logged in. General secretary of Sports Board view, Secretary of a Club  view, Superindent view, Student view. This website is integrated with campus outlook id, and then based on the mail id of the logged-in user we redirect them to the corresponding page.
</b>
<h1>General secretary view:</h1> GenSec can see secys and different clubs in the side navigation bar.<br/>  
<h3>Secys section:</h3>

![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/gs_club_list.png)
<h3>Clubs Section and General Items:</h3>
   This section has two sub fields - Register Stock and Issue History.</br>
i) Register stock

![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/gs_equipment_list.png)

ii) Issue History
![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/gs_issue_list.png)

<h1>Club secretary view:</h1> Club secretary can see different clubs in the side navigation.<br/> 
<h3>Clubs Section and General Items:</h3> 
   This section has two sub fields - Register Stock and Issue History.<br/>
i) Register stock<br/>
Own club section

![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/cs_club_equipment_list.png)

Other clubs section
![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/cs_other_club_equipment_list.png)

ii) Issue History - Issue History of his own club 
![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/cs_issue_list.png)


<h1>Superindent View:</h1> Superindent can see Secys, pending requests and different clubs in the side navigation bar.<br/>  
<h3>Secys section:</h3>  

![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/sup_club_list.png)

<h3>Pending requests:</h3>

![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/sup_pending_request.png)

<h3>Clubs Section and General Items:</h3>  
This section has two sub fields - Register Stock and Issue History.<br/>
i) Register stock

![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/sup_equipment_list.png)

ii) Issue History
![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/sup_issue_list.png)

<h1>Student View:</h1> Students/Staff can see different clubs in the side navigation.<br/>
<h3>Clubs Section and General Items:</h3> 
This section has one sub field - Register Stock.<br/>
i) Register stock

![alt text](https://github.com/kailashnarreddy/sportproject/blob/main/student.png)
   




